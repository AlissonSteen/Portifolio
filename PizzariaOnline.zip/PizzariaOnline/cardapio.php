﻿<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Pizzaria Online</title>
		<link rel="icon" href="img/mussarela.png" type="image"/>
		<link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="lib/owl.carousel/owl-carousel/owl.carousel.css">
		<link rel="stylesheet" href="lib/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/all.css">
		<link rel="stylesheet" href="css/shop.css">

	</head>
	<body>
	<header>

			<div class="container">
				<a href="index.php"><img id="logotipo" src="img/orlando-logo.png" alt="Logotipo"></a>
			</div>

			<div class="header-black">

				<div class="container">
					<ul class="pull-right">
					<span>Seja bem-vindo!</span>
					</ul>
				</div>

			<div class="container">

				<div class="row">

					<nav id="menu" class="pull-right">
						<ul>
							<li><a href="promocoes.php"><i class="fa fa-star" aria-hidden="true"></i> Promoções</a></li>
							<li><a href="contact.php"><i class="fa fa-globe" aria-hidden="true"></i> Contate-nos</a></li>
							<li><a href="cardapio.php"><i class="fa fa-th-list" aria-hidden="true"></i> Cardápio</a></li>
						</ul>
					</nav>

				</div>

			</div>

		</header>

		<section>
			<div class="container">
				  <h3>Cardápio</h3>
					<div class="col-md-8">
						<ul class="nav nav-tabs">
								<li class="active"><a data-toggle="tab" href="#pizzas">Pizzas</a></li>
								<li><a data-toggle="tab" href="#bebidas">Bebidas</a></li>
								<li><a data-toggle="tab" href="#sobremesas">Sobremesas</a></li>
						</ul>
							<div class="tab-content">
									<div id="pizzas" class="tab-pane fade in active">
											<div class="row">
												<?php
										  	include_once("php/conexao.php");
												$consulta = "SELECT * FROM produtos WHERE categoria='Pizza'";
												$resultado = mysqli_query($conexao,$consulta)or die('Erro ao consultar o banco de dados');
												$controle = 1;
												while($controle <=30 && $linha = mysqli_fetch_array($resultado)){
													$imagem = $linha['imagem'];
													$descricao = $linha['descricao'];
													$precoP = $linha['preco'];
													$precoM = $linha['precoM'];
													$precoG = $linha['precoG'];
													$categoria = $linha['categoria'];
													$ingredientes = $linha['ingredientes'];
												if($categoria=='Pizza'){
												?>
								          <div class="rows">
														<div class="col-sm-6 col-md-4">
															<div class="thumbnail">
																<img src="img/<?php echo $imagem;?>" alt="..." style="widt:180px; height: 180px;">
																<div class="caption">
																	<h4><?php echo $descricao; ?></h4>
																	<p>Ingredientes: <?php echo $ingredientes; ?></p>
																	<p><b><?php echo "Pequena R$ ".$precoP."" ?></b></p>
																	<p><b><?php echo "Média R$ ".$precoM."" ?></b></p>
																	<p><b><?php echo "Grande R$ ".$precoG."" ?></b></p>
																	<p></p>
																</div>
															</div>
														</div>
													</div>
												<?php
												$controle++;
											 }
											 	} ?>
						        </div>
						      </div>
								<div id="bebidas" class="tab-pane fade">
									<div class="row">
										<?php
											$consulta1 = "SELECT * FROM produtos WHERE categoria='Bebidas'";
											$resultado1 = mysqli_query($conexao,$consulta1)or die('Erro ao consultar o banco de dados');
											$controle1 = 1;
											while($controle1 <=30 && $linha = mysqli_fetch_array($resultado1)){
												$imagem1 = $linha['imagem'];
												$descricao2 = $linha['descricao'];
												$preco3 = $linha['preco'];
												$categoria1 = $linha['categoria'];

											if($categoria1 == 'Bebidas'){

											?>
											<div class="rows">
												<div class="col-sm-6 col-md-4">
													<div class="thumbnail" style="text-align: center;">
														<img src="img/<?php echo $imagem1;?>" alt="..." style="widt:180px; height: 180px;">
														<div class="caption">
															<h4><?php echo $descricao2; ?></h4>
															<p><?php echo "R$ ".$preco3."" ?></p>
															<p></p>
														</div>
													</div>
												</div>
											</div>
											<?php
											$controle1++;
											}
											} ?>
									</div>
							  </div>

								<div id="sobremesas" class="tab-pane fade">
									<div class="row">
										<?php
											$consulta1 = "SELECT * FROM produtos WHERE categoria='Sobremesa'";
											$resultado1 = mysqli_query($conexao,$consulta1)or die('Erro ao consultar o banco de dados');
											$controle1 = 1;
											while($controle1 <=30 && $linha = mysqli_fetch_array($resultado1)){
												$imagemSobre = $linha['imagem'];
												$descricaoSobre = $linha['descricao'];
												$saborSobre = $linha['sabor'];
												$precoSobre = $linha['preco'];
												$categoriaSobre = $linha['categoria'];

											if($categoriaSobre == 'Sobremesa'){

											?>
											<div class="rows">
												<div class="col-sm-6 col-md-4">
													<div class="thumbnail" style="text-align: center;">
														<img src="img/<?php echo $imagemSobre;?>" alt="..." style="widt:180px; height: 180px;">
														<div class="caption">
															<h4><?php echo $descricaoSobre; ?></h4>
															<h3><?php echo $saborSobre; ?></h3>
															<p><?php echo "R$ ".$precoSobre."" ?></p>
															<p></p>
														</div>
													</div>
												</div>
											</div>
											<?php
											$controle1++;
											}
											} ?>
									</div>
								</div>
						  </div>
					</div>
					<div class="col-md-1">

					</div>
				</div>

					<div id="estatisticas">

					<div class="container">
						<div class="row">
							<div class="col-md-4">
								<p>Formas de pagamento<small>Dinheiro (R$); Cartão crédito (entregador); Cartão débito (entregador).</small></p>
							</div>
							<div class="col-md-4">
								<p>Tempo estimado para entrega<small><i class="fa fa-clock-o" aria-hidden="true"></i> 50 M</small></p>
							</div>
							<div class="col-md-4">
								<p>Peça também pelo telefone<small><i class="fa fa-phone" aria-hidden="true"></i>
								  (88) 3581-0606</small></p>
							</div>
						</div>
					</div>
				</div>
		</section>

		<footer>

			<div class="row row-cinza-claro">

				<div class="container">

					<div class="row">

						<div class="col-md-2 text-center">

							<a href="index.php"><img class="logotipo" src="img/orlando-logo.png" alt="Logotipo"></a>

						</div>
						<div class="col-md-10">

							<div class="row row-cols">
								<div class="col-md-4 col-links">

									<h4>Área Administrativa</h4>
									<ul class="list-unstyled">
										<li><a href="admin/login.php"><i class="fa fa-angle-right"></i>Login</a></li>
									</ul>
									</div>
								<div class="col-md-4 col-links">

									<h4>Links</h4>

									<ul class="list-unstyled">
										<li><a href="promocoes.php"><i class="fa fa-angle-right"></i>Promoções</a></li>
										<li><a href="contact.php"><i class="fa fa-angle-right"></i>Contate-nos</a></li>
										<li><a href="cardapio.php"><i class="fa fa-angle-right"></i>Cardápio</a></li>
									</ul>

								</div>
								<div class="col-md-4 col-get-in-touch">

									<h4>Contatos</h4>

									<address>
										<i class="fa fa-map-marker"></i> <span>13 de Maio, S/N<br/>Iguatu, Ceára</span>
									</address>

									<p><a href="tel:3581-0606"><i class="fa fa-phone"></i> 3581-0606</a></p>


									<ul class="list-unstyled list-socials">
										<li>
											<a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
										</li>
										<li>
											<a href="#" target="_blank"><i class="fa fa-twitter"></i></a>
										</li>
										<li>
											<a href="#" target="_blank"><i class="fa fa-instagram"></i></a>
										</li>
										<li>
											<a href="#" target="_blank"><i class="fa fa-google"></i></a>
										</li>
									</ul>

								</div>
							</div>

						</div>

					</div>

				</div>

			</div>

			<div class="row row-cinza-escuro">

				<div class="container">

					<p class="pull-left">Copyright © Pizzaria Online 2017. All rights reserved.</p>
					<p class="pull-right text-roxo">Created by <a href="https://plus.google.com/u/0/105707711609138552269">World Software</a></p>

				</div>

			</div>

		</footer>

		<script src="lib/jquery/jquery.min.js"></script>
		<script src="lib/owl.carousel/owl-carousel/owl.carousel.min.js"></script>
		<script src="lib/bootstrap/js/bootstrap.min.js"></script>
		<script src="lib/js/jquery.js"></script>
	</body>
</html>
