<?php
  //Botao Voltar
  if(isset($_POST['voltar'])){
    header("Location: ../index.php");
  }
 ?>
 <?php
  if(isset($_POST['sub'])){
    $login = base64_encode($_POST['login']);
    $email = base64_encode($_POST['email']);
    $senha = base64_encode($_POST['senha']);
    $confirmacao = base64_encode($_POST['confisenha']);

    if ($senha == $confirmacao) {
      include_once("../php/connection.php");
      $consulta = "INSERT INTO admin VALUES(0,'$login','$email','$senha','$confirmacao')";
      $resultado = mysqli_query($conexao,$consulta) or die ("Erro ao consultar o banco de dados");
      echo "<script> alert('Cadastro realizado com sucesso'); window.history.go (-1)</script>";
    }else{
      echo "<script> alert('Erro ao cadastrar'); window.history.go (-1)</script>";
    }
  }
  ?>
