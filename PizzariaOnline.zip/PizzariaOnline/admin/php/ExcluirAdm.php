<?php
include_once("connection.php");
$id = $_GET['id'];
$consulta = "DELETE FROM admin WHERE id=$id";
$resultado = mysqli_query($conexao,$consulta)or die("Erro ao consultar BD");
if($resultado){
  echo "<script> alert('Administrador excluído com sucesso!'); window.history.go (-1)</script>";
}else{
  echo "<script> alert('Erro ao excluir Administrador!'); window.history.go (-1)</script>";
}
 ?>
