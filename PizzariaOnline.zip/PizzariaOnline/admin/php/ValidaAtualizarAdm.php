<?php
  //Botao Voltar
  if(isset($_POST['voltar'])){
    header("Location: ../index.php");
  }
 ?>
<?php
 //Pizzas

  if(isset($_POST['sub'])){
    //$id = base64_encode($_POST['id']);
    $login = base64_encode($_POST['login']);
    $email = base64_encode($_POST['email']);
    $senha = base64_encode($_POST['senha']);
    $cs = base64_encode($_POST['confisenha']);


    if ($senha == $cs) {
      include_once("../php/connection.php");
      $consulta = "UPDATE admin SET usuario='$login',email='$email',senha='$senha',confirmasenha='$cs'";
      $resultado = mysqli_query($conexao,$consulta) or die ("Erro ao consultar o banco de dados");
      echo "<script> alert('Cadastro realizado com sucesso'); window.history.go (-1)</script>";
    }else{
      echo "<script> alert('Erro ao cadastrar'); window.history.go (-1)</script>";
    }
}
 ?>
