<?php
  //Botao Voltar
  if(isset($_POST['voltar'])){
    header("Location: ../index.php");
  }
 ?>
<?php
  if(isset($_POST['subPromocoes'])){
    $codigo = $_POST['cod'];
    $preco = $_POST['preco'];
    $titulo = $_POST['titulo'];
    $informacoes = $_POST['infor'];

    $nome = $_FILES['arquivo']['name'];
    $tamanho = $_FILES['arquivo']['size'];
    $numErro = $_FILES['arquivo']['error'];
    $tamaMax = 200000000;

    $erros_arq = array();
    $erros_arq['erros'][0] = 'Não houve erros';
    $erros_arq['erros'][1] = 'Arquivo para upload é maior que o tamanho no PHP';
    $erros_arq['erros'][2] = 'O arquivo ultrapassa o tamanho especificado no HTML';
    $erros_arq['erros'][3] = 'O upload do arquivo foi feito parcialmente';
    $erros_arq['erros'][4] = 'Não foi feito o upload do arquivo';

    $ext = explode(".",$nome); // separa o nome da extensão
    $extFinal = $ext[1];
    $extensoes = array("img","png","jpg","jpeg","PNG","JPG");

    if(in_array($extFinal,$extensoes) && $tamanho < $tamaMax){
      $nomeFinal = utf8_decode("Promocao_Code".$codigo.".".$extFinal);
      if(move_uploaded_file($_FILES['arquivo']['tmp_name'],"../../img/".$nomeFinal)){

          include_once("../php/connection.php");
          $consulta = "INSERT INTO promocoes VALUES(0,'$codigo','$nomeFinal','$preco','$titulo','$informacoes')";
          $resultado = mysqli_query($conexao,$consulta) or die ("Erro ao consultar o banco de dados");
          echo "<script> alert('Cadastro realizado com sucesso'); window.history.go (-1)</script>";
         }
      else{
        echo "<script> alert('Erro ao cadastrar'); window.history.go (-1)</script> ".$erros_arq['erros'][$numErro];
           }
      }
    else{
      echo "<script> alert('Extensão ou Tamanho inválido, envie arquivos com extensão img, png, jpg, jpeg e até 2M'); window.history.go (-1)</script> ".$erros_arq['erros'][$numErro];
    }
  }
?>
