<?php
if (isset($_POST['sub'])){
  $adm = base64_encode($_POST['user']);
  $senha = base64_encode($_POST['pass']);

  include_once('connection.php');
  $consulta = "SELECT * FROM admin WHERE usuario='$adm' AND senha='$senha'";
  $resultado = mysqli_query($conexao, $consulta)or die(mysqli_error($conexao));
  $linhas = mysqli_num_rows($resultado);

  if($linhas){
    session_name('entrar');
    session_start();
    $_SESSION['sessao'] = $adm;
    header("Location: ../index.php");
  }else {
    echo "<script> alert('Administrador nao cadastrado!'); window.history.go (-1)</script>";
  }
  mysqli_close($conexao);
}?>
