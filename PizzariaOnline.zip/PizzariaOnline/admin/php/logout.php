<?php
session_start('entrar');
session_destroy();
header('Location:../login.php');
exit();
?>
