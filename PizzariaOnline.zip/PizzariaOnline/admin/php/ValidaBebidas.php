<?php
  //Botao Voltar
  if(isset($_POST['voltar'])){
    header("Location: ../index.php");
  }
 ?>
<?php
//Bebidas
  if(isset($_POST['sub'])){
    $codigo = $_POST['cod'];
    $Descricao = $_POST['descricao'];
    $sabor = "0";
    $Preco = $_POST['Preco'];
    $Pm = "0";
    $Pg = "0";
    $Ingredientes = "0";
    $Categoria = "Bebidas";

    $nome = $_FILES['arquivo']['name'];
    $tamanho = $_FILES['arquivo']['size'];
    $numErro = $_FILES['arquivo']['error'];
    $tamaMax = 200000000;

    $erros_arq = array();
    $erros_arq['erros'][0] = 'Não houve erros';
    $erros_arq['erros'][1] = 'Arquivo para upload é maior que o tamanho no PHP';
    $erros_arq['erros'][2] = 'O arquivo ultrapassa o tamanho especificado no HTML';
    $erros_arq['erros'][3] = 'O upload do arquivo foi feito parcialmente';
    $erros_arq['erros'][4] = 'Não foi feito o upload do arquivo';

    $ext = explode(".",$nome); // separa o nome da extensão
    $extFinal = $ext[1];
    $extensoes = array("img","png","jpg","jpeg");

    if(in_array($extFinal,$extensoes) && $tamanho < $tamaMax){
      $nomeFinal = utf8_decode("Bebida_Code".$codigo.".".$extFinal);
      if(move_uploaded_file($_FILES['arquivo']['tmp_name'],"../../img/".utf8_decode($nomeFinal))){
          include_once("../php/connection.php");
          $consultaBebi = "INSERT INTO produtos VALUES(0,'$codigo','$nomeFinal','$Descricao','$sabor','$Preco','$Pm','$Pg','$Categoria','$Ingredientes')";
          $resultado1 = mysqli_query($conexao,$consultaBebi) or die (mysqli_error($conexao));
          echo "<script> alert('Cadastro realizado com sucesso'); window.history.go (-1)</script>";
         }
      else{
        echo "<script> alert('Erro ao cadastrar'); window.history.go (-1)</script> ".$erros_arq['erros'][$numErro];
           }
      }
      else{
        echo "<script> alert('Extensão ou Tamanho inválido, envie arquivos com extensão img, png, jpg, jpeg e até 2M'); window.history.go (-1)</script> ".$erros_arq['erros'][$numErro];
      }
  }
 ?>
