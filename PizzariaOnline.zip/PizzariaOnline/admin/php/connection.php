<?php
$host = "mysql.hostinger.com.br";
$user = "u541665099_word";
$pass = "equipeworld";
$bd = "u541665099_pizza";

$conexao = mysqli_connect($host,$user,$pass,$bd)or die("erro ao conectar ao banco");
mysqli_set_charset($conexao,"utf8");
?>
