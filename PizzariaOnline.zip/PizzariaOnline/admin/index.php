﻿<?php
session_name('entrar');
session_start();
if(isset($_SESSION['sessao'])) {
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Área Administrativa</title>
<link rel="icon" href="../img/mussarela.png" type="image"/>
    <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="lib/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/all.css">
    <link rel="stylesheet" href="css/pagprincipal.css">
    <link rel="stylesheet" href="css/pedidos.css">
    <meta HTTP-EQUIV='refresh' CONTENT='1000;URL=index.php'>
  </head>
  <body>
    <head>
      <div id="menu">
        <div class="titulo">
          <span><p><a href="index.php" style="text-decoration: none;">Pizzaria Online</a></p></span>
          <a href="php/logout.php"><span class="btn-sair"><i class="fa fa-sign-out" aria-hidden="true"></i> Sair</span></a>
        </div>
      </div>
    </head>
      <section>
      <div class="container">
          <div class="rows" id="infors">
            <div class="CadPizza">
              <p>Pizzas</p>
              <a href="cadastros/cadastrarPizzas.php"><div class="btn-cadastro"><p>Cadastrar</p></div></a>
              <a href="tabelas/tabelaPizzas.php"><div class="btn-alterar">Alterar Informações</div></a>
            </div>
            <div class="CadBebi">
              <p>Bebidas</p>
              <a href="cadastros/cadastrarBebidas.php"><div class="btn-cadastro"><p>Cadastrar</p></div></a>
              <a href="tabelas/tabelaBebidas.php"><div class="btn-alterar">Alterar Informações</div></a>
            </div>
            <div class="CadSobre">
              <p>Sobremesas</p>
              <a href="cadastros/CadastrarSobremesa.php"><div class="btn-cadastro"><p>Cadastrar</p></div></a>
              <a href="tabelas/tabelaSobremesas.php"><div class="btn-alterar">Alterar Informações</div></a>
            </div>
            <div class="CadAdm">
              <p>Promoções</p>
              <a href="cadastros/CadastrarPromocoes.php"><div class="btn-cadastro"><p>Adicionar</p></div></a>
              <a href="tabelas/tabelaPromocoes.php"><div class="btn-alterar">Alterar Informações</div></a>
            </div>
            <div class="CadAdm">
              <p>Administradores</p>
              <a href="cadastros/CadastrarAdm.php"><div class="btn-cadastro"><p>Cadastrar</p></div></a>
              <a href="tabelas/tabelaAdm.php"><div class="btn-alterar">Alterar Informações</div></a>
            </div>
        </div>
      </div>

    </section>

    <footer>

      <div id="credit" class="row row-cinza-escuro">

        <div class="container cont">

          <p class="pull-left">Copyright © Pizzaria Online 2017. All rights reserved.</p>
          <p class="pull-right text-roxo">Created by <a href="https://plus.google.com/u/0/105707711609138552269">World Software</a></p>

        </div>

      </div>

    </footer>
    <script src="lib/jquery/jquery.min.js"></script>
		<script src="lib/bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>
<?php
  }else{
    echo "<script> alert('Faça login no sistema para continuar'); window.history.go (-1)</script>";
  }
 ?>
