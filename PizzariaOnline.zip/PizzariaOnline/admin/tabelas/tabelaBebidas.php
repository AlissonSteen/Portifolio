﻿<?php
session_name('entrar');
session_start();
if(isset($_SESSION['sessao'])) {
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Tabela de Bebidas</title>
<link rel="icon" href="../../img/mussarela.png" type="image"/>
    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../lib/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../../css/all.css">
    <link rel="stylesheet" href="../css/pagprincipal.css">
    <link rel="stylesheet" href="../css/pedidos.css">
    <link rel="stylesheet" href="../css/cadastros.css">
    <meta HTTP-EQUIV='refresh' CONTENT='2;'>
  </head>
  <body>
    <head>
      <div id="menu">
        <div class="titulo">
          <a href="../index.php" style="text-decoration: none;"><span><p>Pizzaria Online</p></span></a>
          <a href="php/logout.php"><span class="btn-sair"><i class="fa fa-sign-out" aria-hidden="true"></i> Sair</span></a>
        </div>
      </div>
    </head>
    <section>
    <div class="container">
      <div class="col-md-8">
        <?php
        include_once('../php/connection.php');
        $consulta = "select * from produtos where categoria= 'Bebidas'";
        $resultado=mysqli_query($conexao,$consulta)or die('Erro ao consultar ');
        echo "<table class='table tabelaP'>
          <thead class='thead-inverse'>
            <tr class=''>
              <th>Código</th>
              <th>Imagem</th>
              <th>Descrição</th>
              <th>Preço</th>
              <th>Editar</th>
              <th>Excluir</th>
            </tr>
            </thead>";
        while($lista=mysqli_fetch_array($resultado)){
         echo "<tr><td>".$lista['codigo']."</td>";
         echo "<td>".$lista['imagem']."</td>";
         echo "<td>".$lista['descricao']."</td>";
         //echo "<td>".$lista['sabor']."</td>";
         echo "<td>".$lista['preco']."</td>";
         //echo "<td>".$lista['precoM']."</td>";
         //echo "<td>".$lista['precoG']."</td>";
         //echo "<td>".$lista['ingredientes']."</td>";
         echo "<td><a href='../cadastros/EditarBebidas.php?id=".$lista['id']."' title='Editar'><i class='fa fa-pencil-square-o' aria-hidden='true' style='color: black; margin-left: 12px;'></i></a></td>";
         echo "<td><a href='../php/ExcluirProduto.php?id=".$lista['id']."' title='Excluir'><i class='fa fa-trash' aria-hidden='true' style='color: black; margin-left: 18px;'></i></a></td></tr>";
        }
        echo "</table>";
        mysqli_close($conexao);
          ?>
          <form action="#" method="post">
          <button type="submit" name="voltar">Retornar</button>
          <?php
            //Botao Voltar
            if(isset($_POST['voltar'])){
              header("Location: ../index.php");
            }
           ?>
         </form>
      </div>
  </section>
  <footer>
    <div id="credit5" class="row row-cinza-escuro">

      <div class="container cont">

        <p class="pull-left">Copyright © Pizzaria Online 2017. All rights reserved.</p>
        <p class="pull-right text-roxo">Created by <a href="https://plus.google.com/u/0/105707711609138552269">World Software</a></p>

      </div>

    </div>

  </footer>
    <script src="lib/jquery/jquery.min.js"></script>
		<script src="lib/bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>
<?php
  }else{
    echo "<script> alert('Faça login no sistema para continuar'); window.history.go (-1)</script>";
  }
 ?>
