﻿<?php
session_name('entrar');
session_start();
if(isset($_SESSION['sessao'])) {
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Editar Sobremesas</title>
<link rel="icon" href="../../img/mussarela.png" type="image"/>
    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../lib/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../../css/all.css">
    <link rel="stylesheet" href="../css/pagprincipal.css">
    <link rel="stylesheet" href="../css/pedidos.css">
    <link rel="stylesheet" href="../css/cadastros.css">
  </head>
  <body>
    <head>
      <div id="menu">
        <div class="titulo">
          <a href="../index.php" style="text-decoration: none;"><span><p>Pizzaria Online</p></span></a>
          <a href="../php/logout.php"><span class="btn-sair"><i class="fa fa-sign-out" aria-hidden="true"></i> Sair</span></a>
        </div>
      </div>
    </head>
    <section>
    <div class="container">
      <div class="col-md-8">
        <?php
          $id = $_GET['id'];
          include_once('../php/connection.php');
          $consulta = "SELECT * FROM produtos WHERE id='$id'";
          $res = mysqli_query($conexao, $consulta) or die ('Erro ao carregar dados!');
          $produtos = mysqli_fetch_array($res);
          //
         ?>
        <form action="../php/ValidaAtualizarSobremesas.php" enctype="multipart/form-data" method="post">
          <label class="Form-00" style="visibility:hidden">
            <input type="hidden" name="id" value="<?= $id ?>">
          </label>
          <label class="Form-00">
            <span>Código</span>
            <input type="text" name="cod" value="<?php echo $produtos['codigo']; ?>">
          </label>
          <label class="Form-00">
            <span>Descrição</span>
            <input type="text" name="descricao" value="<?php echo $produtos['descricao']; ?>">
          </label>
          <label class="Form-00">
            <span>Sabor</span>
            <input type="text" name="sabor" value="<?php echo $produtos['sabor']; ?>">
          </label>
          <label class="Form-00">
            <span>Imagem</span>
            <input type="file" name="arquivo" value="<?php echo $produtos['imagem']; ?>">
          </label>
          <label class="Form-00">
            <span>Preço</span>
            <input type="text" name="preco" value="<?php echo $produtos['preco']; ?>">
          </label>
          <button type="submit" name="sub">Alterar</button>
          <button type="submit" name="voltar">Retornar</button>
        </form>
      </div>
    </div>
  </section>
  <footer>
    <div id="credit3" class="row row-cinza-escuro">

      <div class="container cont">

        <p class="pull-left">Copyright © Pizzaria Online 2017. All rights reserved.</p>
        <p class="pull-right text-roxo">Created by <a href="https://plus.google.com/u/0/105707711609138552269">World Software</a></p>

      </div>

    </div>

  </footer>
    <script src="lib/jquery/jquery.min.js"></script>
		<script src="lib/bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>
<?php
  }else{
    echo "<script> alert('Faça login no sistema para continuar'); window.history.go (-1)</script>";
  }
 ?>
