﻿<?php
session_name('entrar');
session_start();
if(isset($_SESSION['sessao'])) {
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Editar Administradores</title>
<link rel="icon" href="../../img/mussarela.png" type="image"/>
    <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../lib/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../../css/all.css">
    <link rel="stylesheet" href="../css/pagprincipal.css">
    <link rel="stylesheet" href="../css/pedidos.css">
    <link rel="stylesheet" href="../css/cadastros.css">
  </head>
  <body>
    <head>
      <div id="menu">
        <div class="titulo">
          <a href="../index.php" style="text-decoration: none;"><span><p>Pizzaria Online</p></span></a>
          <a href="../php/logout.php"><span class="btn-sair"><i class="fa fa-sign-out" aria-hidden="true"></i> Sair</span></a>
        </div>
      </div>
    </head>
    <section>
    <div class="container">
      <div class="col-md-8">
        <?php
          $id = $_GET['id'];
          include_once('../php/connection.php');
          $consulta = "SELECT * FROM admin WHERE id='$id'";
          $res = mysqli_query($conexao, $consulta) or die ('Erro ao carregar dados!');
          $admin = mysqli_fetch_array($res);
          //
         ?>
        <form action="../php/ValidaAtualizarAdm.php" enctype="multipart/form-data" method="post">
          <label class="Form-00" style="visibility:hidden">
            <input type="hidden" name="id" value="<?= $id ?>">
          </label>
          <label class="Form-00">
            <span>Login</span>
            <input type="text" name="login" value="<?php echo base64_decode($admin['usuario']); ?>">
          </label>
          <label class="Form-00">
            <span>E-mail</span>
            <input type="mail" name="email" value="<?php echo base64_decode($admin['email']); ?>">
          </label>
          <label class="Form-00">
            <span>Senha</span>
            <input type="text" name="senha" value="<?php echo base64_decode($admin['senha']); ?>">
          </label>
          <label class="Form-00">
            <span>Confirmar Senha</span>
            <input type="text" name="confisenha" value="<?php echo base64_decode($admin['confirmasenha']); ?>">
          </label>
          <button type="submit" name="sub">Alterar</button>
          <button type="submit" name="voltar">Retornar</button>
        </form>
      </div>
    </div>
  </section>
  <footer>
    <div id="credit6" class="row row-cinza-escuro">

      <div class="container cont">

        <p class="pull-left">Copyright © Pizzaria Online 2017. All rights reserved.</p>
        <p class="pull-right text-roxo">Created by <a href="https://plus.google.com/u/0/105707711609138552269">World Software</a></p>

      </div>

    </div>

  </footer>
    <script src="lib/jquery/jquery.min.js"></script>
		<script src="lib/bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>
<?php
  }else{
    echo "<script> alert('Faça login no sistema para continuar'); window.history.go (-1)</script>";
  }
 ?>
