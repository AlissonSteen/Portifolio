<?php
if(isset($_POST['mensagem'])){
  $nome = $_POST["nome"];
  $email = $_POST["email"];
  $tel = $_POST["fone"];
  $msg = $_POST["msg"];

if($nome == null){

echo "<script>alert('O campo Nome � obrigat�rio'); window.history.go (-1)</script>";

}else if($email == null){

echo "<script>alert('O campo E-mail � obrigat�rio!'); window.history.go (-1)</script>";

}else if($tel == null){

echo "<script>alert('O campo Telefone � obrigat�rio!'); window.history.go (-1)</script>";

}else if($msg == null){

echo "<script>alert('O campo de mensagem � obrigat�rio!'); window.history.go (-1)</script>";

}else{

  $para = "wordsoftwareigt@gmail.com";
  $destino = $para;
  $assunto = "Contato Pizzaria Online";
  $mensagem = "Nome: ".$nome."\n".
              "E-mail: ".$email."\n".
              "Telefone: ".$tel."\n".
              "Mensagem: ".$msg."\n";

  $enviarEmail = mail($destino,$assunto,$mensagem);

  if ($enviarEmail) {
    echo "<script>alert('Enviado com sucesso!'); window.history.go (-1)</script>";
  }else{
  	echo "<script>alert('Erro ao enviar!'); window.history.go (-1)</script>";
  }

}

}
 ?>
